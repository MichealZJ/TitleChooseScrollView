//
//  ViewController.m
//  chooseScrollView_demo
//
//  Created by 张建 on 16/2/18.
//  Copyright © 2016年 Dr.com. All rights reserved.
//

#import "ViewController.h"
#define DEVICE_WIDTH  [UIScreen mainScreen].bounds.size.width
#define DEVICE_HEIGHT [UIScreen mainScreen].bounds.size.height
typedef enum {
    topScrollView  = 0,
    tableScrollView
}ScrollViewTag;

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>
@property (nonatomic,assign) NSUInteger number;
@property (nonatomic,strong) NSMutableArray *sliderViews;
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) NSNumber *currentPageN;
@end

@implementation ViewController
{
    UIScrollView *_topScrollView;
    UIButton *_sliderButton;
    UIView *_sliderIndexView;
    UIScrollView *_tableScrollView;
    CGFloat _sliderView_width;
    CGPoint lastOffSet ;
    NSInteger page;
}

- (NSMutableArray *)sliderViews{
    
    if (!_sliderViews) {
        _sliderViews = [NSMutableArray array];
    }
    return _sliderViews;
}
- (UITableView *)tableView{
    
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(DEVICE_WIDTH*([self.currentPageN intValue]-1), 0, DEVICE_WIDTH, _tableScrollView.frame.size.height) style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
    }
    return _tableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    //初始化一些参数
    [self initParameter];
    //选项卡滚动视图
    [self addTopScrollView];
    //选项卡视图
    [self addSliderView];
    //选项卡下标视图
    [self addSliderIndexView];
    //下部tableView视图
    [self addTableScroolView];
    //在用户将后台程序移除后，需要知道针对这个动作的触发时间／方法（通知）
    [[NSNotificationCenter defaultCenter]  addObserver:self selector:@selector(applicationWillDidEnterBackground:) name:UIApplicationDidEnterBackgroundNotification object:[UIApplication sharedApplication]];
}

- (void)applicationWillDidEnterBackground:(NSNotification *)notification {
    
    NSLog(@"程序开始进入后台.");
    
    //4. 在触发方法中去保存你要保存的数据
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    //使用defaults来保存用户数据的名字/年龄文本
    [defaults setObject:[NSNumber numberWithInteger:page] forKey:@"currentPage"];
    
    //强制将用户输入的名字和年龄数据保存到硬盘中
    [defaults synchronize];
    
}

- (void)initParameter{
    
    self.number = 4;
    _sliderView_width = DEVICE_WIDTH/4.0;
    lastOffSet = CGPointZero;
    
    //获取全局的NSUserDefault对象, 取出存储的当前页数
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];

    self.currentPageN = [defaults objectForKey:@"currentPage"];
    if (self.currentPageN) {
        page = [self.currentPageN integerValue];
    }else{
        page = 0;
    }
    
}
- (void)addTopScrollView{
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    _topScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 64, DEVICE_WIDTH, 55)];
    _topScrollView.delegate = self;
    _topScrollView.backgroundColor = [UIColor greenColor];
    _topScrollView.tag = topScrollView;
    _topScrollView.contentSize = CGSizeMake(_sliderView_width*self.number, 55);
    
    [self.view addSubview:_topScrollView];
}

- (void)addSliderView{
    
    for (int i = 0; i < self.number; i++) {
        _sliderButton = [[UIButton alloc]initWithFrame:CGRectMake(i*_sliderView_width, 0, _sliderView_width, 50)];
        _sliderButton.tag = i;
        [_sliderButton setTitle:@"分类名" forState:UIControlStateNormal];
        [_topScrollView addSubview:_sliderButton];
        [self.sliderViews addObject:_sliderButton];
    }
}

- (void)addSliderIndexView{
    
    _sliderIndexView = [[UIView alloc]initWithFrame:CGRectMake(_sliderView_width*[self.currentPageN floatValue], 50, _sliderView_width, 5)];
    _sliderIndexView.backgroundColor = [UIColor redColor];
    [_topScrollView addSubview:_sliderIndexView];

}
- (void)addTableScroolView {
    
    CGFloat x = _topScrollView.frame.size.height+64;
    _tableScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, x, DEVICE_WIDTH, DEVICE_HEIGHT-x)];
    _tableScrollView.contentSize = CGSizeMake(DEVICE_WIDTH*self.number, DEVICE_HEIGHT-x);
    _tableScrollView.tag = tableScrollView;
    _tableScrollView.contentOffset = CGPointZero;
    lastOffSet = _tableScrollView.contentOffset;
    _tableScrollView.backgroundColor = [UIColor orangeColor];
    _tableScrollView.pagingEnabled = YES;
    _tableScrollView.delegate = self;
    [_tableScrollView addSubview:self.tableView];
    [self.view addSubview:_tableScrollView];
}


#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 15;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static  NSString *reuseIdentifier = @"reuse";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    }
    if (self.currentPageN) {
        
        cell.textLabel.text = [NSString stringWithFormat:@"第%d页第%ld行数据",[self.currentPageN intValue],(long)indexPath.row];
    }else{
        cell.textLabel.text = [NSString stringWithFormat:@"第%ld页第%ld行数据",(long)page,(long)indexPath.row];
    }
        return cell;
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
   
    if (scrollView.tag == topScrollView) {
        
        NSLog(@"顶部滚动视图");
    }else if (scrollView.tag == tableScrollView){
        NSLog(@"底部滚动视图");
        //判断当前滑动距离来确定选项卡下标偏移位置
        CGPoint point = scrollView.contentOffset;
        CGFloat sliderIndex_X = point.x/DEVICE_WIDTH*_sliderView_width;
        //在主线程更新frame
        dispatch_async(dispatch_get_main_queue(), ^{
            [_sliderIndexView setFrame:CGRectMake(sliderIndex_X, _sliderIndexView.frame.origin.y, _sliderView_width, 5)];
        });
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    //在主线程更新frame
     page = scrollView.contentOffset.x/DEVICE_WIDTH;
    self.currentPageN = [NSNumber numberWithFloat:page];
//    if (scrollView.contentOffset.x > lastOffSet.x) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView  setFrame:CGRectMake(page*DEVICE_WIDTH, 0, DEVICE_WIDTH, _tableScrollView.frame.size.height)];
            [self.tableView reloadData];
        });
//    }else{
//        [self.tableView  setFrame:CGRectMake(0, 0, DEVICE_WIDTH, _tableScrollView.frame.size.height)];
//    }
    lastOffSet = scrollView.contentOffset;
    
}
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
  
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
