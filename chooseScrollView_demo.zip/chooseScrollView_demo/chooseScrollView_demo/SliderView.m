//
//  SliderView.m
//  chooseScrollView_demo
//
//  Created by 张建 on 16/2/18.
//  Copyright © 2016年 Dr.com. All rights reserved.
//

#import "SliderView.h"

@implementation SliderView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
